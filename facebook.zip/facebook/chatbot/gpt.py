import openai
import os
os.environ["OPENAI_API_KEY"] = "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"

def get_response(user_message):
    openai.api_key = os.environ["OPENAI_API_KEY"]
    model_engine = "text-davinci-002" # thay đổi thành mô hình GPT mà bạn muốn sử dụng
    prompt = f"User: {user_message}\nBot:"

    response = openai.Completion.create(
        engine=model_engine,
        prompt=prompt,
        max_tokens=60,
        n=1,
        stop=None,
        temperature=0.5
    )

    return response.choices[0].text.strip()
