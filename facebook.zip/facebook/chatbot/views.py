from django.shortcuts import render
from django.http import JsonResponse
from chatbot.gpt import get_response

from django.http import JsonResponse
from chatbot.gpt import get_response

def chatbot(request):
    user_message = request.GET.get('user_message', '')
    bot_response = get_response(user_message)
    return JsonResponse({'bot_response': bot_response})


