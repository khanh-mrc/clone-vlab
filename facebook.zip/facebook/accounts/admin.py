from django.contrib import admin
from .models import Usera

admin.site.register(Usera)
# Register your models here.
